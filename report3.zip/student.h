#define MAX 24
#define START_ID 1401001
struct student {
   char name[MAX];
   int id;
   int score;
};
