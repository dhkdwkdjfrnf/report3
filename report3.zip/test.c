#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "student.h"


int menu_display(void);
void dbcreate();
void dbquery();
void dbupdate();
void press_any_key(void);





int main(void)
{
    int c;
    while((c = menu_display())!=0)
    {
        switch(c)
        {
            case 1 : dbcreate();
                break;
            case 2 : dbquery();
                break;
            case 3 : dbupdate();
                break;
            default: break;
        }
    }
    return 0;
}
int menu_display(void)
{
    int select;
    printf("select \n\n");
    printf("1. db create\n");
    printf("2. db query\n");
    printf("3. db update\n\n");
    printf("0. exit\n\n");
    printf("enter > ");
    scanf("%d", &select);
    return select;
}

void dbcreate(){
	char* fname = (char *) malloc(sizeof(char) * MAX-1);
	printf("Please enter file name : ");
    scanf("%s",fname);
    int fd;
    struct student rec;

    if ((fd = open(fname,O_WRONLY |O_CREAT, 0640))==-1) {
        perror(fname);
        exit(2);
    }

    printf("%-9s %-8s %-4s", "ID",  "Name",  "Score"); 
    while (scanf("%d %s %d", &rec.id, rec.name, &rec.score) ==  3) {
        lseek(fd, (rec.id - START_ID) * sizeof(rec), SEEK_SET);
        write(fd, &rec, sizeof(rec) );
    }

    close(fd);
    exit(0);

}
void dbquery(){
	char* fname = (char *) malloc(sizeof(char) * MAX-1);
    printf("Please enter file name : ");
    scanf("%s",fname);
    int fd, id;
    char c;
    struct student rec;

   if ((fd = open(fname, O_RDONLY)) == -1) {
        perror(fname);
        exit(2);
    }

    do {
        printf("\nEnter the student's ID:");
        if (scanf("%d", &id) == 1) {
            lseek(fd, (id-START_ID)*sizeof(rec), SEEK_SET);
            if ((read(fd, &rec, sizeof(rec)) > 0) && (rec.id != 0)) 
                printf("ID:%d\t Name:%s\t Score:%d\n", 
                        rec.id, rec.name, rec.score);
            else printf("Record %d None\n", id);
        }
        else printf("Input error"); 

        printf("Continue?(Y/N)");
        scanf(" %c", &c);
    } while (c == 'Y');
   
    close(fd);
    exit(0);

}
void dbupdate(){
    char* fname = (char *) malloc(sizeof(char) * MAX-1);
    printf("Please enter file name : ");
    scanf("%s",fname);
    int fd, id;
    char c;
    struct student rec;

    if ((fd = open(fname, O_RDWR)) == -1) {
        perror(fname);
        exit(2);
    }

    do {
        printf("Enter the student's ID: ");
        if (scanf("%d", &id) == 1) {
            lseek(fd,  (long) (id-START_ID)*sizeof(rec), SEEK_SET);
            if ((read(fd, &rec, sizeof(rec)) > 0) && (rec.id != 0)) {
                printf("ID:%8d\t Name:%4s\t Score:%4d\n", 
                       rec.id, rec.name, rec.score);
           printf("New score: ");
           scanf("%d", &rec.score);
                lseek(fd, (long) -sizeof(rec), SEEK_CUR);
                write(fd, &rec, sizeof(rec));
            }
            else printf("Record %d None\n", id);
        }
        else printf("Input error\n");
        printf("Continue?(Y/N)");
        scanf(" %c",&c);
    } while (c == 'Y');

    close(fd);
    exit(0);

}

